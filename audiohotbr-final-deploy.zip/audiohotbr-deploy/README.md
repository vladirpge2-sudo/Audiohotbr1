# AudioHotBr - Plataforma #1 do Brasil

A maior plataforma de conteúdo erótico do Brasil com áudios, vídeos, fotos e textos com vozes brasileiras.

## 📋 Informações do Projeto

- **Nome:** AudioHotBr
- **Versão:** 1.0.0
- **Tipo:** Site Estático HTML/CSS/JavaScript
- **Status:** Pronto para Produção

## 🚀 Como Usar

### Desenvolvimento Local
```bash
python3 -m http.server 3000
```
Acesse: `http://localhost:3000`

### Deploy em Produção
Este projeto está configurado para ser deployado em:
- **Vercel** (recomendado)
- **Netlify**
- **GitHub Pages**
- Qualquer servidor web estático

## 📁 Estrutura

```
audiohotbr-deploy/
├── index.html       # Página principal
├── package.json     # Configuração do projeto
├── vercel.json      # Configuração Vercel
├── .gitignore       # Arquivos ignorados pelo Git
└── README.md        # Este arquivo
```

## 🔧 Configuração

O site é totalmente estático e não requer backend ou banco de dados.

## 📝 Licença

Todos os direitos reservados © 2026 AudioHotBr
